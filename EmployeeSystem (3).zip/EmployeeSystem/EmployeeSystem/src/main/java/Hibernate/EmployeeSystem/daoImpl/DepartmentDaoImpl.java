package Hibernate.EmployeeSystem.daoImpl;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import Hibernate.EmployeeSystem.dao.DepartmentDAO;
import Hibernate.EmployeeSystem.entity.Department;
import Hibernate.EmployeeSystem.util.HibernateUtil;

public class DepartmentDaoImpl implements DepartmentDAO {
	private SessionFactory sessionFactory;
	private DepartmentDAO departmentDao;
    // Constructor to inject SessionFactory
    public DepartmentDaoImpl(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    
	//GetAll Department
	public List<Department>getDepartment()
	{
		try(Session session=HibernateUtil.getSessionFactory().openSession())
		{
			return session.createQuery("from Department", Department.class).list();
		}
	}
	}

			


				
