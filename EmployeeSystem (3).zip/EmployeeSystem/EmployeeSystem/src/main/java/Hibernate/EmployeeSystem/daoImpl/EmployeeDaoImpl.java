package Hibernate.EmployeeSystem.daoImpl;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;


import Hibernate.EmployeeSystem.dao.EmployeeDao;
import Hibernate.EmployeeSystem.entity.Employee;
import Hibernate.EmployeeSystem.util.HibernateUtil;


public class EmployeeDaoImpl implements EmployeeDao {
	private SessionFactory sessionFactory;
    private EmployeeDao employeeDAO;
    //Validation
    private Validator validator;

    // Constructor to inject SessionFactory
    public EmployeeDaoImpl(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        this.validator = factory.getValidator();
    }
    @Override
	public void saveEmployee(Employee employee) {
    	//To Validate employee
        Set<ConstraintViolation<Employee>> violations = validator.validate(employee);
        if (!violations.isEmpty()) {
            for (ConstraintViolation<Employee> violation : violations) {
                System.out.println(violation.getMessage());
            }
            return;
        }
        Session session = sessionFactory.getCurrentSession();
        Transaction transaction = session.beginTransaction();

        session.save(employee); // Save employee to the database

        transaction.commit(); // Commit the transaction
        System.out.println("Employee added successfully!");
    }		

    @Override
	public void updateEmployee(Employee employee)
	{
    	//To Validate employee
        Set<ConstraintViolation<Employee>> violations = validator.validate(employee);
        if (!violations.isEmpty()) {
            for (ConstraintViolation<Employee> violation : violations) {
                System.out.println(violation.getMessage());
            }
            return;
        }
    	 Session session = sessionFactory.openSession();
         Transaction transaction = null;

         try {
             // Start a transaction
             transaction = session.beginTransaction();
             session.update(employee);
             // Commit the transaction
             transaction.commit();
             System.out.println("Employee updated successfully!");
         } catch (Exception e) {
             // Rollback in case of an error
             if (transaction != null) {
                 transaction.rollback();
             }
             e.printStackTrace();
         } finally {
             session.close();
         }
     }
    
    @Override
	public void deleteEmployee(int employee_id)
	{
    	Session session = sessionFactory.openSession();
        Transaction transaction = null;
        try {
            // Start a transaction
            transaction = session.beginTransaction();
            // Retrieve the employee by ID
            Employee employee = session.get(Employee.class, employee_id);
            if (employee != null) {
                // Delete the employee
                session.delete(employee);
            }
            // Commit the transaction
            transaction.commit();
        } catch (Exception e) {
            // Rollback in case of an error
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            session.close();
        }
    }
    
    @Override
	//GetAll Employee
	public List<Employee>getEmployee()
	{
		try(Session session=HibernateUtil.getSessionFactory().openSession())
		{
			return session.createQuery("from Employee", Employee.class).list();
		}
	}
}