package Hibernate.EmployeeSystem.entity;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "Project")
public class Project {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int prj_id;
    
    @Column(length=20,nullable=false)
    @NotNull(message="Project name is required")
    @Size(min=2,max=20)
    private String prj_name;
    
    @Column(length=6,nullable=false)
    @NotNull(message="Budget is required")
    private Double budget;
    
    @Column(length=20,nullable=false)
    @NotNull(message="Status is required")
    @Size(min=2,max=20)
    private String status;

	public int getPrj_id() {
		return prj_id;
	}

	public void setPrj_id(int prj_id) {
		this.prj_id = prj_id;
	}

	public String getPrj_name() {
		return prj_name;
	}

	public void setPrj_name(String prj_name) {
		this.prj_name = prj_name;
	}

	public Double getBudget() {
		return budget;
	}

	public void setBudget(Double budget) {
		this.budget = budget;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Project(int prj_id, @NotNull(message = "Project name is required") @Size(min = 2, max = 20) String prj_name,
			@NotNull(message = "Budget is required") Double budget,
			@NotNull(message = "Status is required") @Size(min = 2, max = 20) String status) {
		super();
		this.prj_id = prj_id;
		this.prj_name = prj_name;
		this.budget = budget;
		this.status = status;
	}

	public Project() {
		super();
	}

	@Override
	public String toString() {
		return "Project [prj_id=" + prj_id + ", prj_name=" + prj_name + ", budget=" + budget + ", status=" + status
				+ "]";
	}
    
    
}
