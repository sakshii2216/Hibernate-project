package Hibernate.EmployeeSystem.service;

import java.util.List;

import Hibernate.EmployeeSystem.dao.RoleDao;
import Hibernate.EmployeeSystem.entity.Role;

public class RoleService {
	private RoleDao roleDAO;
	
    public RoleService(RoleDao roleDAO) {
        this.roleDAO = roleDAO;
    }
    //List of all roles
        public List<Role> getRoles() {
        return roleDAO.getRole();
    }
}