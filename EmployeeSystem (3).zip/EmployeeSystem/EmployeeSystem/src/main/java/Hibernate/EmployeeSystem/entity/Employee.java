package Hibernate.EmployeeSystem.entity;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "employee")
public class Employee {
	@Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int employee_id;
    
    @Column(length=20,nullable=false)
    @NotNull(message="Enter the employee's first name")
    @Size(min=2,max=20)
    private String first_name;
    
    @Column(length=20,nullable=false)
    @NotNull(message="Enter the employee's last name")
    @Size(min=2,max=20)
    private String last_name;
      
    @Column(length=30,nullable=false,unique=true)
    @NotNull(message="Email is required")
    @Email(message="Email should be valid")
    private String email;
    
    @Column(length=10,nullable=false,unique=true)
    @NotNull(message="Phone number is required")
    @Pattern(regexp="[6789]{1}[0-9]{9}",message="Enter proper phone number")
    private String phone;

    @OneToOne
    @JoinColumn(name="dept_id")
    private Department department;
    
    @OneToOne
    @JoinColumn(name="prj_id")
    private Project project;
    
    @OneToOne
    @JoinColumn(name="role_id")
    private Role role;
    
	public int getEmployee_id() {
		return employee_id;
	}

	public void setEmployee_id(int employee_id) {
		this.employee_id = employee_id;
	}

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public Employee(int employee_id,
			@NotNull(message = "Enter the employee's first name") @Size(min = 2, max = 20) String first_name,
			@NotNull(message = "Enter the employee's last name") @Size(min = 2, max = 20) String last_name,
			@NotNull(message = "Email is required") @Email(message = "Email should be valid") String email,
			@NotNull(message = "Phone number is required") @Pattern(regexp = "[6789]{1}[0-9]{9}", message = "Enter proper phone number") String phone) {
		super();
		this.employee_id = employee_id;
		this.first_name = first_name;
		this.last_name = last_name;
		this.email = email;
		this.phone = phone;
	}

	public Employee() {
		super();
	}

	@Override
	public String toString() {
		return "Employee [employee_id=" + employee_id + ", first_name=" + first_name + ", last_name=" + last_name
				+ ", email=" + email + ", phone=" + phone + "]";
	}
    
    
    
}
