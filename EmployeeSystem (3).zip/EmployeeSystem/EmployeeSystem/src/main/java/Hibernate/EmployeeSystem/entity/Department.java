package Hibernate.EmployeeSystem.entity;

import javax.validation.constraints.NotNull;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "department")
public class Department {
	 @Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private int dept_id;
	    
	    @Column(length=20,nullable=false)
	    @NotNull(message="Department name is required")
	    private String dept_name;
	    
	    @Column(length=6,nullable=false)
	    @NotNull(message="Budget is required")
	    private Double budget;

		public int getDept_id() {
			return dept_id;
		}

		public void setDept_id(int dept_id) {
			this.dept_id = dept_id;
		}

		public String getDept_name() {
			return dept_name;
		}

		public void setDept_name(String dept_name) {
			this.dept_name = dept_name;
		}

		public Double getBudget() {
			return budget;
		}

		public void setBudget(Double budget) {
			this.budget = budget;
		}

		public Department(int dept_id, @NotNull(message = "Department name is required") String dept_name,
				@NotNull(message = "Budget is required") Double budget) {
			super();
			this.dept_id = dept_id;
			this.dept_name = dept_name;
			this.budget = budget;
		}

		public Department() {
			super();
		}

		@Override
		public String toString() {
			return "Department [dept_id=" + dept_id + ", dept_name=" + dept_name + ", budget=" + budget + "]";
		}
	    
	    
}
