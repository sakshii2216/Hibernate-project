package Hibernate.EmployeeSystem.service;

import java.util.List;

import Hibernate.EmployeeSystem.dao.DepartmentDAO;
import Hibernate.EmployeeSystem.dao.ProjectDao;
import Hibernate.EmployeeSystem.entity.Department;
import Hibernate.EmployeeSystem.entity.Project;

public class ProjectService {
	private ProjectDao projectDao;

    // Constructor to inject DAO
    public ProjectService(ProjectDao projectDao) {
        this.projectDao = projectDao;
    }

    // Add a new project
    public void save(Project project) {
        projectDao.saveProject(project);
    }

    // Get all project
    public List<Project> getAllProject() {
        return projectDao.getProject();
    }
}
