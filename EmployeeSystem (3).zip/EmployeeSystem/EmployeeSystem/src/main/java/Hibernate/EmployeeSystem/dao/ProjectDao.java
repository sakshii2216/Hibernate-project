package Hibernate.EmployeeSystem.dao;

import java.util.List;
import Hibernate.EmployeeSystem.entity.Project;

public interface ProjectDao {
	//it is to add proejects
	void saveProject(Project project);
	
	//to list all projects
	List<Project>getProject();
}

