package Hibernate.EmployeeSystem.service;

import java.util.List;

import Hibernate.EmployeeSystem.dao.EmployeeDao;
import Hibernate.EmployeeSystem.entity.Employee;

public class EmployeeService {
	 private EmployeeDao employeeDAO;

	    // Constructor to inject DAO
	    public EmployeeService(EmployeeDao employeeDAO) {
	        this.employeeDAO = employeeDAO;
	    }

	    //This adds Employee
	    public void save(Employee employee) {
	        employeeDAO.saveEmployee(employee);
	    }

	    //This updates employee
	    public void updateEmployee(Employee employee) {
	        employeeDAO.updateEmployee(employee);
	    }
	    
	    //This deletes employee
	    public void deleteEmployee(int employee_id) {
	        employeeDAO.deleteEmployee(employee_id);
	    }

	    //List of all employees
	    public List<Employee> getEmployee() {
	        return employeeDAO.getEmployee();
	    }
}
