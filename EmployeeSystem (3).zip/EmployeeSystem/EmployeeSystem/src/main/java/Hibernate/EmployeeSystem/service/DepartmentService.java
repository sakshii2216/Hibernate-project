package Hibernate.EmployeeSystem.service;

import java.util.List;

import Hibernate.EmployeeSystem.dao.DepartmentDAO;
import Hibernate.EmployeeSystem.dao.EmployeeDao;
import Hibernate.EmployeeSystem.entity.Department;
import Hibernate.EmployeeSystem.entity.Employee;

public class DepartmentService {
	private DepartmentDAO departmentDao;
	
	//Constructor
	public DepartmentService(DepartmentDAO departmentDao) {
		this.departmentDao = departmentDao;
	}
		    //List of all departments
		    
		    public List<Department> getDepartment() {
		        return departmentDao.getDepartment();
		    }
	}
