package Hibernate.EmployeeSystem.daoImpl;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import Hibernate.EmployeeSystem.dao.ProjectDao;
import Hibernate.EmployeeSystem.dao.RoleDao;
import Hibernate.EmployeeSystem.entity.Employee;
import Hibernate.EmployeeSystem.entity.Project;
import Hibernate.EmployeeSystem.entity.Role;
import Hibernate.EmployeeSystem.util.HibernateUtil;

public class ProjectDaoImpl implements ProjectDao {
	private SessionFactory sessionFactory;
    private ProjectDao projectDao;
    //Validation
    private Validator validator;

    // Constructor to inject SessionFactory
    public ProjectDaoImpl(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        this.validator = factory.getValidator();
    }
   
	public void saveProject(Project project) {
    	//To Validate role
        Set<ConstraintViolation<Project>> violations = validator.validate(project);
        if (!violations.isEmpty()) {
            for (ConstraintViolation<Project> violation : violations) {
                System.out.println(violation.getMessage());
            }
            return;
        }
        Session session = sessionFactory.getCurrentSession();
        Transaction transaction = session.beginTransaction();

        session.save(project); // Save employee to the database

        transaction.commit(); // Commit the transaction
        System.out.println("Project added successfully!");
    }		

	//GetAll Projects
	public List<Project>getProject()
	{
		try(Session session=HibernateUtil.getSessionFactory().openSession())
		{
			return session.createQuery("from Project", Project.class).list();
		}
}
}