package Hibernate.EmployeeSystem.dao;

import java.util.List;
import Hibernate.EmployeeSystem.entity.Employee;

public interface EmployeeDao{
	//It is to add employee
	void saveEmployee(Employee employee);
	
	//It is to update employee
	void updateEmployee(Employee employee);
	
	//deleting employee by id
	void deleteEmployee(int employee_id);
	
	//list of all employee
    List<Employee>getEmployee();    
}
