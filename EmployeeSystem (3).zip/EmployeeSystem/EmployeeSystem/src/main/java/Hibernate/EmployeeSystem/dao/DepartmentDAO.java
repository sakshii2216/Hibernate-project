package Hibernate.EmployeeSystem.dao;

import java.util.List;
import Hibernate.EmployeeSystem.entity.Department;

	public interface DepartmentDAO {
		//To view all Departments
		List<Department>getDepartment();
	}

