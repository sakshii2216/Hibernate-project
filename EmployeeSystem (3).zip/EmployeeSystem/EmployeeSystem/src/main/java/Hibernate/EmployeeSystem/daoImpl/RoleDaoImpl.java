package Hibernate.EmployeeSystem.daoImpl;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import Hibernate.EmployeeSystem.dao.RoleDao;
import Hibernate.EmployeeSystem.entity.Role;
import Hibernate.EmployeeSystem.util.HibernateUtil;

public class RoleDaoImpl implements RoleDao {
	private SessionFactory sessionFactory;
    private RoleDao roleDao;
    //Validation
    private Validator validator;

    // Constructor to inject SessionFactory
    public RoleDaoImpl(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        this.validator = factory.getValidator();
    }
	public void saveRole(Role role) {
    	//To Validate role
        Set<ConstraintViolation<Role>> violations = validator.validate(role);
        if (!violations.isEmpty()) {
            for (ConstraintViolation<Role> violation : violations) {
                System.out.println(violation.getMessage());
            }
            return;
        }
        Session session = sessionFactory.getCurrentSession();
        Transaction transaction = session.beginTransaction();

        session.save(role); // Save employee to the database

        transaction.commit(); // Commit the transaction
        System.out.println("Role added successfully!");
    }		

	public void updateRole(Role role)
	{
		Transaction transaction=null;
		try(Session session=HibernateUtil.getSessionFactory().openSession())
		{
			//Start Transaction
			transaction=session.beginTransaction();
			String hql = "UPDATE Employee set rolename = :rolename " + "WHERE role_id = :role_id";
			Query query = session.createQuery(hql);
			query.setParameter("rolename", role.getRole_name());
			query.setParameter("role_id", 1);
			int result=query.executeUpdate();
			System.out.println("Rows affected:"+result);
		transaction.commit();
		}
		catch(Exception e)
		{
			if(transaction!=null)
			{
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}
	public void deleteStudent(int role_id)
	{

		Transaction transaction=null;
		try(Session session=HibernateUtil.getSessionFactory().openSession())
		{
			//Start Transaction
			transaction=session.beginTransaction();
			Role role=session.get(Role.class, role_id);
			if(role!=null)
			{
				String hql="DELETE FROM Role "+ "where role_id=:role_id";
				Query query=session.createQuery(hql);
			
				query.setParameter("id", role_id);
				int result=query.executeUpdate();
				System.out.println("Rows affected:"+result);
			}
				transaction.commit();
			}
			catch(Exception e)
			{
				if(transaction!=null)
				{
					transaction.rollback();
				}
				e.printStackTrace();
			}
			}
	public Role getRole(int role_id)

	{

		Transaction transaction=null;
		Role role=null;
		try(Session session=HibernateUtil.getSessionFactory().openSession())
		{
			//Start Transaction
			transaction=session.beginTransaction();
			
			
				String hql="FROM Role E WHERE E.role_id=:role_id";
				Query query=session.createQuery(hql);
			
				query.setParameter("id",role_id);
				List result=query.getResultList();
				if( result!=null&&!result.isEmpty())
				{
					role=(Role)result.get(0);
				
				//System.out.println("Rows affected:"+result);
			}
				transaction.commit();
			}
			catch(Exception e)
			{
				if(transaction!=null)
				{
					transaction.rollback();
				}
				e.printStackTrace();
			}
		return role;
		}

	//GetAll Role
	public List<Role>getRole()
	{
		try(Session session=HibernateUtil.getSessionFactory().openSession())
		{
			return session.createQuery("from Role", Role.class).list();
		}
	}
	}