package Hibernate.EmployeeSystem.dao;

import java.util.List;
import Hibernate.EmployeeSystem.entity.Role;

public interface RoleDao {
	//to list all roles
	List<Role>getRole();
		}

