package Hibernate.EmployeeSystem;

import java.util.*;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import Hibernate.EmployeeSystem.entity.*;
import Hibernate.EmployeeSystem.dao.*;
import Hibernate.EmployeeSystem.daoImpl.*;
import Hibernate.EmployeeSystem.service.*;

public class App {

    // Instance variables
    private SessionFactory factory;
    private DepartmentDAO departmentDao;
    private EmployeeDao employeeDao;
    private ProjectDao projectDao;
    private RoleDao roleDao;
    private DepartmentService departmentService;
    private EmployeeService employeeService;
    private ProjectService projectService;
    private RoleService roleService;

    private static Scanner scanner = new Scanner(System.in);
    private static String adminUsername = "sakshi";
    private static String adminPassword = "sakshi22";

    public App() {
        //XML configuration
        factory = new Configuration()
            .configure("hibernate.cfg.xml") // Configuration file
            .addAnnotatedClass(Employee.class)
            .addAnnotatedClass(Department.class)
            .addAnnotatedClass(Role.class)
            .addAnnotatedClass(Project.class)
            .buildSessionFactory();

        departmentDao = new DepartmentDaoImpl(factory);
        departmentService = new DepartmentService(departmentDao);

        employeeDao = new EmployeeDaoImpl(factory);
        employeeService = new EmployeeService(employeeDao);
        
        projectDao = new ProjectDaoImpl(factory);
        projectService = new ProjectService(projectDao);
        
        roleDao = new RoleDaoImpl(factory);
        roleService = new RoleService(roleDao);
    }

    public static void main(String[] args) {
        App app = new App(); //
        if (app.adminLogin()) {
            app.showMenu();
        } else {
            System.out.println("Invalid credentials. Exiting...");
        }
    }

    private boolean adminLogin() {
    	System.out.println("--------------Employee Management System--------------");
        System.out.println("Enter Admin Username: ");
        String username = scanner.nextLine();
        System.out.println("Enter Admin Password: ");
        String password = scanner.nextLine();

        return username.equals(adminUsername) && password.equals(adminPassword);
    }

    private void showMenu() {
        boolean running = true;
        while (running) {
            System.out.println("\nEmployee Management System Menu:");
            System.out.println("1. Add Employee");
            System.out.println("2. Update Employee");
            System.out.println("3. View All Employees");
            System.out.println("4. Add a project");
            System.out.println("5. Get all projects");
            System.out.println("6. List of Departments");
            System.out.println("7. List of Roles");
            System.out.println("8. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline character
            
            switch (choice) {
            case 1:
                // Add employee
                System.out.print("Enter employee id: ");
                int empid = scanner.nextInt();
                scanner.nextLine(); // Consume leftover newline
                System.out.print("Enter Employee's first name: ");
                String fname = scanner.nextLine();
                System.out.print("Enter Employee's last name: ");
                String lname = scanner.nextLine();
                System.out.print("Enter email: ");
                String email = scanner.nextLine();
                System.out.print("Enter phone: ");
                String phone = scanner.nextLine();

                Employee employee = new Employee(empid, fname, lname, email, phone);

                try {
                    employeeService.save(employee); // Adds the employee
                    System.out.println("Employee added successfully!");
                } catch (IllegalArgumentException e) {
                    System.out.println("Error: " + e.getMessage()); // Show validation error
                }
                break;
                
            case 2:
                // Update employee
                System.out.print("Enter employee id to update: ");
                int emp_id = scanner.nextInt();
                scanner.nextLine(); // Consume leftover newline
                System.out.print("Enter Employee's first name: ");
                String firstname = scanner.nextLine();
                System.out.print("Enter Employee's last name: ");
                String lastname = scanner.nextLine();
                System.out.print("Enter email: ");
                String email1 = scanner.nextLine();
                System.out.print("Enter phone: ");
                String phone1 = scanner.nextLine();

                Employee employeeToUpdate = new Employee(emp_id, firstname, lastname, email1, phone1);
                try {
                    employeeService.updateEmployee(employeeToUpdate); // This will update the employee
                    System.out.println("Employee updated successfully!");
                } catch (IllegalArgumentException e) {
                    System.out.println("Error: " + e.getMessage()); // Show validation error
                }
                break;
                
            case 3:
                // To view all employees
                List<Employee> employees = employeeService.getEmployee();
                if (employees.isEmpty()) {
                    System.out.println("No employees found!");
                } else {
                    employees.forEach(System.out::println);
                }
                break;

            case 4:
                // Add project
                System.out.print("Enter project id: ");
                int prj_id = scanner.nextInt();
                scanner.nextLine(); // Consume leftover newline
                System.out.print("Enter Project Name: ");
                String prj_name = scanner.nextLine();
                System.out.print("Enter Project Budget: ");
                Double budget = scanner.nextDouble();
                scanner.nextLine(); // Consume leftover newline
                System.out.print("Enter Project Status: ");
                String status = scanner.nextLine();
             
                Project project = new Project(prj_id, prj_name, budget, status);

                try {
                    projectService.save(project); // Adds project
                    System.out.println("Project is added successfully!");
                } catch (IllegalArgumentException e) {
                    System.out.println("Error: " + e.getMessage()); // Shows validation error
                }
                break;

            case 5:
                // Get all projects
                List<Project> projects = projectService.getAllProject();
                if (projects.isEmpty()) {
                    System.out.println("No projects found!");
                } else {
                    projects.forEach(System.out::println);
                }
                break;
            
            case 6:
                // List of Departments
                List<Department> dpt = departmentService.getDepartment();
                if (dpt.isEmpty()) {
                    System.out.println("Some error occurred. Please try again.");
                } else {
                    dpt.forEach(System.out::println);
                }
                break;

            case 7:
                // List of roles
                List<Role> role = roleService.getRoles();
                if (role.isEmpty()) {
                    System.out.println("Some unexpected error occurred!");
                } else {
                    role.forEach(System.out::println);
                }
                break;

            case 8:
                System.out.println("Exiting...");
                running = false;
                break;

            default:
                System.out.println("Invalid choice, please try again.");
            }
        }
        // Close resources
        scanner.close();
        factory.close();
    }
}