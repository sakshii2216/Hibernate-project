package Hibernate.EmployeeSystem.entity;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "Role")
public class Role {
	@Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
   private int role_id;
   
   @Column(length=20,nullable=false)
   @NotNull(message="Enter the role of employee")
   @Size(min=2,max=20)
   private String role_name;

public int getRole_id() {
	return role_id;
}

public void setRole_id(int role_id) {
	this.role_id = role_id;
}

public String getRole_name() {
	return role_name;
}

public void setRole_name(String role_name) {
	this.role_name = role_name;
}

public Role(int role_id, @NotNull(message = "Enter the role of employee") @Size(min = 2, max = 20) String role_name) {
	super();
	this.role_id = role_id;
	this.role_name = role_name;
}

public Role() {
	super();
}

@Override
public String toString() {
	return "Role [role_id=" + role_id + ", role_name=" + role_name + "]";
}
   
   
}

